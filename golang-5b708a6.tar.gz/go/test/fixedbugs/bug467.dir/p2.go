package p2

import "./p1"

func SockUnix() error { var s *p1.SockaddrUnix; return s }
